/* eslint-disable no-unused-vars */
export default {
    id: "test",
    function: async function ({ client, Discord, interaction, choices }) {
        interaction.reply("test");
    }
}