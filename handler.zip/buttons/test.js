/* eslint-disable no-unused-vars */
export default {
    id: "", // button custom id here
    permissions: [],
    roleRequired: "985070408581656616",
    function: async function ({ client, Discord, button }) {
        button.reply("test");
    }
}